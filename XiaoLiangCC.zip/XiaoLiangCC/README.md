# CCforKogan
Using the provided (paginated) API, find the average cubic weight for all products in the "Air Conditioners" category.  Cubic weight is calculated by multiplying the length, height and width of the parcel. The result is then multiplied by the industry standard cubic weight conversion factor of 250.

## Installation:
```
npm install
```

## Execution:
```
npm start
```
or directly run it via node
```
node index.js
```

## Testing:
```
npm install nodemon
npm test
```
or directly run it via nodemon
```
nodemon index.js
```
