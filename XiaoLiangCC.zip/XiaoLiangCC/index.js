//---------------------------------libraries
const axios = require('axios');
//---------------------------------constants
const API_URL = 'http://wp8m3he1wt.s3-website-ap-southeast-2.amazonaws.com';
const DECIMAL_DIGITS= 4;                   //based on greatest level of accuracy in the given data
const CONVERSION_FACTOR = 250;
//---------------------------------global variables
var AC_LISTS = [];


//---------------------------------functions
//------calculate the average cubic weight of all products in the "Air Conditioners" category under given api url----------//
const avg_ac_cubic_weight = (url) => {
  return axios.get(url)
  .then((res)=>{
    /*---------------------successful request result starts here---------------------*/

    //---------------------filter products by category & retrieve products' size
    ac_prods = res.data.objects
      .filter(item => item.category == 'Air Conditioners')
      .map(item => item.size);
    console.log(`Found ${ac_prods.length} products in the "Air Conditioners" category under ${url.replace(API_URL,'')}`); 

    //---------------------add found products' value(w*l*h) to the total list
    if (ac_prods.length > 0){
      AC_LISTS = AC_LISTS.concat(ac_prods.map(item => item.width*item.length*item.height));
    }
    //---------------------go to next page if exists
    if(res.data.next){
      return avg_ac_cubic_weight(`${API_URL}${res.data.next}`);
    }
    //---------------------otherwise sum up all products'value in AC_LISTS & multiply the conversion factor & calculate the average cubic weight & 
    else{
      return AC_LISTS.reduce((a,b) => a+b)*CONVERSION_FACTOR/AC_LISTS.length/Math.pow(100,3);
    }
  })
  .catch((err)=>{
    /*---------------------error logging---------------------*/
    console.log(err);
  });
}

//--------------------------------------------------------------------------------------------------------------------------//
/*----------------------------------------------------------------------------------------------------------Start requesting*/
avg_ac_cubic_weight(`${API_URL}/api/products/1`).then(res => {
  console.log(`\nThe average cubic weight for all products in the "Air Conditioners" category is \n${res.toFixed(DECIMAL_DIGITS)} in kg, ${(res*1000).toFixed(DECIMAL_DIGITS)} in g.`);
});